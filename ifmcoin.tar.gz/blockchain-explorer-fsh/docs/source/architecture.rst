--
--    SPDX-License-Identifier: Apache-2.0
--

Architecture Reference
----------------------

TODO
~~~~

.. short overview of the HL Explorer architecture


.. toctree::
   :maxdepth: 1

   architecture/ui_presentation
   architecture/backend







.. Licensed under Creative Commons Attribution 4.0 International License
   https://creativecommons.org/licenses/by/4.0/


