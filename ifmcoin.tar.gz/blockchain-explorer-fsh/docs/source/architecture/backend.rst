--
--    SPDX-License-Identifier: Apache-2.0
--

Backend Layer
===========================================

An overview of the backend layer

  TODO

		
  .. .. image:: ../images/backend.png
  .. :width: 850px

.. toctree::
   :maxdepth: 1


.. Licensed under Creative Commons Attribution 4.0 International License
   https://creativecommons.org/licenses/by/4.0/
