// SPDX-License-Identifier: Apache-2.0
// add new version of fabric here
const Version = ['v1.4'];

export default Version;
