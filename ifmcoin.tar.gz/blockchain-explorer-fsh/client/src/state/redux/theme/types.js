/**
 *    SPDX-License-Identifier: Apache-2.0
 */

const namespaces = 'theme';

const CHANGE_THEME = `${namespaces}/CHANGE_THEME`;

export default {
  CHANGE_THEME,
};
