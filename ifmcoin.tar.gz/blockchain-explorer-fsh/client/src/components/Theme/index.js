// SPDX-License-Identifier: Apache-2.0
import Theme from './Theme';

export default Theme;
