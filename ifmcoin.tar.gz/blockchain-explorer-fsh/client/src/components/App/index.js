//SPDX-License-Identifier: Apache-2.0

import App from './App';

export default App;
